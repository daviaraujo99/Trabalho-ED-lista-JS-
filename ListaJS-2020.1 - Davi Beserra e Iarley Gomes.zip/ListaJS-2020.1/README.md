# FilaJS

Project intended to teach ***Linked List*** data structure in JavaScript for students undergraduate.