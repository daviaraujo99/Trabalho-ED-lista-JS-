class OrderedLinkedList extends LinkedList {
    constructor() {
        super()
        this.temp = null
    }

    append(value, pos) {
        if (isNaN(value) || !value) {
            if (this.head) return this.head.content;
            return 'Não há nenhum nó.'
        } //para a adição de nós se o valor passado não for um número ou estiver vazio

        if (this.head) {
            super.append(value); //atualiza a head com o novo nó incluído
            let node = this.head; //variável de controle
            const numbers = []; //array para ordenação de nós

            //estura de repetição que popula o nosso array para uma posterior ordenação
            while (node) {
                numbers.push(node.content);
                node = node.next;
            }

            //ordena os números
            numbers.sort(function(a, b) {
                return a - b;
            });

            //zera a head para refazê-la ordenada
            this.head = null;

            //mapeia nossos números e cria os nós ordenadamente
            numbers.map(number => super.append(number));

            if (pos) alert(new Error("Não é permitido inserir na posição em listas ordenadas"));
            //retorna o conteúdo do primeiro nó para visualização
            return this.head.content;
        }

        super.append(value);
        return this.head.content;
    }

    remove(value) {
        if (isNaN(value) || !value) {
            if (this.head) return this.head.content;
            return 'Não há nenhum nó.'
        } //para a remoção de nós se o valor passado não for um número ou estiver vazio

        super.remove(value);
        return this.head.content;
    }

    roam(direction) {
        if(!this.head) return alert("Não existe nenhum nó");
        switch(direction) {
            case 'next':
                if(!this.head.next) return alert("Não existe próximo nó");
                if(!this.temp) {
                    this.temp = this.head.next;
                    return this.temp.content;
                }

                if(!this.temp.next) return alert("Não existe próximo nó");
                this.temp = this.temp.next;

                return this.temp.content;
            case 'restart':
                this.temp = this.head;
                return this.head.content;
            default:
                break;
        }
    }

    insert(value, pos) {
        this.append(value, pos)
        throw new Error("Não é permitido inserir na posição em listas ordenadas")
    }

    delete(value) {
        this.remove(value)
    }
}
