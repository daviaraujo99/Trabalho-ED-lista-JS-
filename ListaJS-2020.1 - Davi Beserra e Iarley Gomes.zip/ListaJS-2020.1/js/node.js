class Node {
    constructor(value) {
        this.prev = null
        this.content = value
        this.next = null
    }
}