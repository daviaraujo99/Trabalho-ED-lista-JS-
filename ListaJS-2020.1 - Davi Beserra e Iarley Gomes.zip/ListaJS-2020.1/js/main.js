var list = new OrderedArrayList();
var linkedList = new OrderedLinkedList();

$().ready(function () {
    $('#insert').click(insertElement)
    $('#insert_at').click(insertElementAt)
    $('#remove').click(removeElement)
    $('#remove_at').click(removeElementAt)
    $('#insert_linked_list').click(insertElementLinkedList)
    $('#next_linked_list').click(nextElementLinkedList)
    $('#insert_at_linked_list').click(insertAtLinkedList)
    $('#remove_linked_list').click(removeElementLinkedList)
    $('#restart_linked_list').click(restartLinkedList)
})

function showData() {
    let text = `<div class="ui label" style="margin-left: 5px">
                    ${list.toString('</div><div class="ui label" style="margin-left: 5px">')}
                </div>`
    let out = $('#output');
    out.empty()
    out.append(text)
}
function showLinkedData(value) {
    let out = $('#output_linked_list');
    out.empty();
    out.append(value);
}
function insertElement() {
    let val = prompt('digite um valor a ser inserido:')
    list.append(parseInt(val))
    showData();
}
function insertElementAt() {
    try {
        let val = parseInt(prompt('digite um valor a ser inserido:'))
        let pos = parseInt(prompt('digite uma posição a inserir:'))
        list.insert(pos, parseInt(val))
    } catch (error) {
        alert(error)
    }
    showData();
}
function removeElement() {
    let val = prompt('digite um valor a ser removido:')
    if (val.length < 0) return
    let el = list.remove(val)
    if (el) {
        alert(`removido o elemento ${el}`)
    } else {
        alert('valor não encontrado')
    }
    showData();
}
function removeElementAt() {
    let pos = prompt('digite uma posição a remover:')
    if (pos.length < 0) return
    let el = list.removeAt(pos)
    if (el) {
        alert(`removido o elemento ${el}`)
    } else {
        alert('posição inválida')
    }
    showData();
}

// LINKED LIST METHODS

function insertElementLinkedList() {
    try {
        let val = parseInt(prompt('digite um valor a ser inserido:'))
        let node = linkedList.append(val)
        showLinkedData(node)
    } catch (error) {
        alert(error)
    }
}
function nextElementLinkedList() {
    try {
        let node = linkedList.roam('next')
        showLinkedData(node)
    } catch (error) {
        alert(error)
    }
}
function insertAtLinkedList() {
    try {
        let val = parseInt(prompt('digite um valor a ser inserido:'))
        let pos = parseInt(prompt('digite uma posição a inserir:'))
        let node = linkedList.append(val, pos)
        showLinkedData(node)
    } catch (error) {
        alert(error)
    }
}
function removeElementLinkedList() {
    try {
        let val = parseInt(prompt('digite um valor a ser removido:'))
        let node = linkedList.delete(val)
        showLinkedData(node)
    } catch (error) {
        alert(error)
    }
}
function restartLinkedList() {
    try {
        let node = linkedList.roam('restart')
        showLinkedData(node)
    } catch (error) {
        alert(error)
    }
}
